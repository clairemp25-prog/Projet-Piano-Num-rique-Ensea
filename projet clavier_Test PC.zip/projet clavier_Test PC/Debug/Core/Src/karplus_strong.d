Core/Src/karplus_strong.o: ../Core/Src/karplus_strong.c \
 ../Core/Inc/karplus_strong.h
../Core/Inc/karplus_strong.h:
