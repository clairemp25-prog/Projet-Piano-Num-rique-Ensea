/*
 * main_pc.c
 *
 *  Created on: May 21, 2026
 *      Author: widad
 */

/// code tq pas besoin des fonctionnalités STM

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#define STM32 0   // important pour désactiver HAL

#include "karplus_strong.h"
#include "adsr.h"

#define SAMPLE_RATE 16000
#define DURATION_SEC 2.0

void write_wav(const char *filename, int16_t *data, int samples)
{
    FILE *f = fopen(filename, "wb");

    int byte_rate = SAMPLE_RATE * 2;
    int block_align = 2;
    int subchunk2_size = samples * 2;

    fwrite("RIFF", 1, 4, f);
    uint32_t chunk_size = 36 + subchunk2_size;
    fwrite(&chunk_size, 4, 1, f);
    fwrite("WAVE", 1, 4, f);

    fwrite("fmt ", 1, 4, f);
    uint32_t subchunk1_size = 16;
    fwrite(&subchunk1_size, 4, 1, f);
    uint16_t audio_format = 1;
    fwrite(&audio_format, 2, 1, f);
    uint16_t num_channels = 1;
    fwrite(&num_channels, 2, 1, f);
    uint32_t sr = SAMPLE_RATE;
    fwrite(&sr, 4, 1, f);
    
    fwrite(&byte_rate, 4, 1, f);
    fwrite(&block_align, 2, 1, f);
    uint16_t bits_per_sample = 16;
    fwrite(&bits_per_sample, 2, 1, f);

    fwrite("data", 1, 4, f);
    fwrite(&subchunk2_size, 4, 1, f);

    fwrite(data, 2, samples, f);
    fclose(f);
}

int main()
{
    KarplusStrong_t ks;
    ADSR_t env;

    ADSR_Init(&env, 0.002f, 0.01f, 0.4f, 0.005f);
   // KS_Init(&ks, 440.0f, 0.996f); // note jouer dans le test
    
//     // pls notes a la suite 
//     float notes[] = {261.63f, 293.66f, 329.63f, 349.23f}; // Do Ré Mi Fa
// int nb_notes = 4;
// 
// int pos = 0;
// float buffer_f[SAMPLE_RATE * 10]; // 10 sec max
// 
// for (int n = 0; n < nb_notes; n++) {
// 
//     // Réinitialiser l'ADSR et le KS pour chaque note
//     ADSR_Init(&env, 0.01f, 0.2f, 0.8f, 0.3f);
//     KS_Init(&ks, notes[n], 0.996f);
// 
//     ADSR_NoteOn(&env);
// 
//     // Durée de la note (0.5 sec)
//     for (int i = 0; i < SAMPLE_RATE * 0.5; i++) {
//         float sample = KS_Step(&ks) * ADSR_Step(&env);
//         buffer_f[pos++] = sample;
//     }
// 
//     // Lâcher la note
//     ADSR_NoteOff(&env);
// 
//     // Laisser le release se terminer (0.2 sec)
//     for (int i = 0; i < SAMPLE_RATE * 0.2; i++) {
//         float sample = KS_Step(&ks) * ADSR_Step(&env);
//         buffer_f[pos++] = sample;
//     }
// }


    //accord de Do majeur (do mi sol)
    
float notes[] = {261.63f, 329.63f, 392.00f};
int nb_notes = 3;

// Instances multiples
KarplusStrong_t ks_accord[3];
ADSR_t envs[3];

int pos = 0;
float buffer_f[SAMPLE_RATE * 10];

// Initialisation des 3 notes
for (int n = 0; n < nb_notes; n++) {
    ADSR_Init(&envs[n], 0.01f, 0.2f, 0.8f, 0.3f);
    KS_Init(&ks_accord[n], notes[n], 0.996f);
    ADSR_NoteOn(&envs[n]);
}

// Durée de l’accord : 1 seconde
for (int i = 0; i < SAMPLE_RATE * 1.0f; i++) {

    float mix = 0.0f;

    for (int n = 0; n < nb_notes; n++) {
        float s = KS_Step(&ks_accord[n]) * ADSR_Step(&envs[n]);
        mix += s;
    }

    mix /= nb_notes; // normalisation
    buffer_f[pos++] = mix;
}

// Release des 3 notes
for (int n = 0; n < nb_notes; n++)
    ADSR_NoteOff(&envs[n]);

for (int i = 0; i < SAMPLE_RATE * 0.3f; i++) {

    float mix = 0.0f;

    for (int n = 0; n < nb_notes; n++) {
        float s = KS_Step(&ks_accord[n]) * ADSR_Step(&envs[n]);
        mix += s;
    }

    mix /= nb_notes;
    buffer_f[pos++] = mix;
}


int total_samples = pos; 
int16_t *buffer = malloc(total_samples * sizeof(int16_t));
 

    for (int i = 0; i < total_samples; i++) {
    float s = buffer_f[i];
    if (s > 1.0f) s = 1.0f;
    if (s < -1.0f) s = -1.0f;
    buffer[i] = (int16_t)(s * 32767.0f);
}


    write_wav("test.wav", buffer, total_samples);
    free(buffer);

    return 0;
}

