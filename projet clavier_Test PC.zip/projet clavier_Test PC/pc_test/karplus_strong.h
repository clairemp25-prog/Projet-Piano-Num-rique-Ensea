/*
 * main_pc.c
 *
 *  Created on: May 21, 2026
 *      Author: widad
 */

#pragma once
#include <stdint.h>

#define SAMPLE_RATE      16000
#define MAX_BUFFER_SIZE  512
#define NUM_NOTES        9

typedef struct {
    float    buffer[MAX_BUFFER_SIZE];
    uint16_t size;
    uint16_t index;
    float    damping;
    uint8_t  active;
} KarplusStrong_t;

void  KS_Init(KarplusStrong_t *ks, float frequency, float damping);
float KS_Step(KarplusStrong_t *ks);
